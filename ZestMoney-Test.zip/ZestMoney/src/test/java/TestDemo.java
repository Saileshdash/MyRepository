import org.testng.annotations.Test;

import com.zestmoney.util.BaseTest;

public class TestDemo extends BaseTest{

	@Test
	public void testDemo() {
		System.out.println("Hiiii");
	}
}
